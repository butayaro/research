import os.path

class ScmPath:
    @staticmethod
    def normrelativepath(path):
        return path.strip('/')

    @staticmethod
    def ospath(path):
        return path.replace('/', os.sep)

    @staticmethod
    def makesuredir(dirname):
        dirname = ScmPath.ospath(dirname)
        try:
            if not os.path.isdir(dirname):
                try:
                    os.remove(dirname)
                except:
                    pass
                os.makedirs(dirname)
            elif not os.access(dirname, os.W_OK):
                raise FileNotFoundError(dirname + ': not writable')
        except OSError:
            raise

    @staticmethod
    def keyname(root, filename):
        if filename.find(root) != 0:
            raise RuntimeError(filename + ' is not in ' + root)
        keyname = filename[len(root):]
        return keyname.lstrip('/')
