import os.path
import subprocess
import re
import uuid
import time
import shutil
from .scmpath import ScmPath

UUIDFILE = '.uuid'
CACHE_DIR_PREFIX = 'cache'
BD_DIR_PREFIX = 'bd'
MARK_PREFIX = '._'

class BD:
    def __init__(self, cache_dir='.', device='/dev/null', format='ISO'):
        self.cache_dir = os.path.join(cache_dir, CACHE_DIR_PREFIX)
        ScmPath.makesuredir(self.cache_dir)
        self.bd_dir = os.path.join(cache_dir, BD_DIR_PREFIX)
        ScmPath.makesuredir(self.bd_dir)
        self.uuid = os.path.join(cache_dir, UUIDFILE)
        self.device = device
        self.re_files_7z = re.compile(r' 1 files\n', re.MULTILINE)
        self.re_no_files_7z = re.compile(r'No files to process$', re.MULTILINE)
        self.re_1_file_7z = re.compile(r'Files read from disk: 1$', re.MULTILINE)
        self.re_OK_7z = re.compile(r'Everything is Ok$', re.MULTILINE)
        self.format = format

    def bdexistp(self, path):
        out = subprocess.check_output([
            '7z', 'l', '-y', '-t' + self.format, self.device, path
        ],
        universal_newlines=True)
        match = self.re_files_7z.search(out)
        return match is not None

    def bdextract(self, path):
        out = subprocess.check_output([
            '7z', 'x', '-y', '-t' + self.format, '-o' + self.cache_dir, self.device, path
        ],
        universal_newlines=True)
        return self.re_no_files_7z.search(out) is None and os.access(os.path.join(self.cache_dir, path), os.R_OK)

    def bdinit_7z(self):
        uuidstr = str(uuid.uuid4())
        print(uuidstr)
        with open(self.uuid, "wb") as fp:
            fp.write(uuidstr.encode('utf-8'))

        out = subprocess.check_output([
            '7z', 'a', '-y', '-t' + self.format, self.device, self.uuid
        ],
        universal_newlines=True)
        print(out)
        if self.re_1_file_7z.search(out) is not None:
            return uuidstr
        raise RuntimeError(out)

    def bdinit_iso(self):
        uuidstr = str(uuid.uuid4())
        print(uuidstr)
        with open(self.uuid, "wb") as fp:
            fp.write(uuidstr.encode('utf-8'))

        try:
            out = subprocess.check_output([
                'growisofs', '-Z', self.device, '-use-the-force-luke=notray', '-R', '-J', self.uuid
                ],
                stderr=subprocess.STDOUT
            )
            return uuidstr
        except subprocess.CalledProcessError as e:
            raise RuntimeError(e.output.decode('utf-8'))

    def bdinit(self):
        if self.format.lower() != 'ISO'.lower():
            return self.bdinit_7z()
        return self.bdinit_iso()

    @staticmethod
    def make_markpath(path):
        return os.path.join(os.path.dirname(path), MARK_PREFIX + os.path.basename(path))

    @staticmethod
    def make_mark(path):
        mark_path = BD.make_markpath(path)
        with open(mark_path, "wb") as f:
            f.write(str(time.time()).encode('utf-8'))

    def make_links(self):
        count = 0
        for root, subdirs, files in os.walk(self.cache_dir):
            keyname = ScmPath.keyname(self.cache_dir, root)
            for filename in files:
                if filename.find(MARK_PREFIX) == 0:
                    continue
                file_path = os.path.join(root, filename)
                mark_path = BD.make_markpath(file_path)
                if os.access(mark_path, os.R_OK):
                    continue
                to_path = os.path.join(self.bd_dir, keyname, filename)

                '''
                print('\t- file %s (full path: %s)' % (filename, file_path))
                print(to_path)
                '''

                ScmPath.makesuredir(os.path.dirname(to_path))
                try:
                    os.remove(to_path)
                    print(to_path + ': already existing')
                except OSError:
                    pass
                os.link(file_path, to_path)
                BD.make_mark(file_path)
                count += 1
        return count

    def bdflush_7z(self, clean):
        count = self.make_links()
        out = subprocess.check_output([
            '7z', 'a', '-y', '-t' + self.format, self.device, os.path.join(self.bd_dir, '.')
        ],
        universal_newlines=True)
        if self.re_OK_7z.search(out) is not None:
            shutil.rmtree(self.bd_dir)
            ScmPath.makesuredir(self.bd_dir)
            if clean:
                shutil.rmtree(self.cache_dir)
                ScmPath.makesuredir(self.cache_dir)
            return count
        raise RuntimeError('failed to write files to bd')

    def bdflush_iso(self, clean):
        count = self.make_links()
        try:
            out = subprocess.check_call([
                'growisofs', '-M', self.device, '-use-the-force-luke=notray', '-R', '-J', self.bd_dir
            ])
            shutil.rmtree(self.bd_dir)
            ScmPath.makesuredir(self.bd_dir)
            if clean:
                shutil.rmtree(self.cache_dir)
                ScmPath.makesuredir(self.cache_dir)
            return count
        except subprocess.CalledProcessError as e:
            print(e)
            raise RuntimeError('failed to write files to bd')

    def bdflush(self, clean):
        if self.format.lower() != 'ISO'.lower():
            return self.bdflush_7z(clean)
        return self.bdflush_iso(clean)

    def existp(self, path):
        path = ScmPath.ospath(path)
        if os.access(os.path.join(self.cache_dir, path), os.R_OK):
            return True
        return self.bdexistp(path)

    def openr(self, name):
        path = ScmPath.ospath(os.path.join(self.cache_dir, name))
        try:
            fp = open(os.path.join(self.cache_dir, path), "rb")
        except FileNotFoundError:
            if self.bdextract(name):
                BD.make_mark(path)
                fp = open(os.path.join(self.cache_dir, path), "rb")
            else:
                raise RuntimeError(name + ': not in bd')
        return fp

    def open_to_download(self, path):
        path = os.path.join(self.cache_dir, path)
        path = ScmPath.ospath(path)
        ScmPath.makesuredir(os.path.dirname(path))
        fp = open(path, "wb")
        if fp is not None:
            try:
                mark_path = BD.make_markpath(path)
                os.remove(mark_path)
                print(mark_path + ': mark removed')
            except:
                pass
            return fp
