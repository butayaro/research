import boto
from boto.s3.connection import S3Connection,OrdinaryCallingFormat,SubdomainCallingFormat
from boto.s3.key import Key
from boto.exception import S3ResponseError,BotoClientError,BotoServerError
import os.path
from datetime import datetime
from .scmpath import ScmPath
from . bd import BD


class S3Access:
    conn = None;

    def __init__(self, accessKey, secret, host, port = 8000, bd = None):
        self.host = host if host != None else S3Connection.DefaultHost
        self.port = port
        self.accessKey = accessKey
        self.secret = secret
        if bd is None:
            raise RunTimeError('S3Access: bd should not be None')
        self.bd = bd
        self.kw = dict(
            host = self.host,
            port = self.port,
            is_secure = False,
            calling_format = (SubdomainCallingFormat() if self.host == S3Connection.DefaultHost
                else OrdinaryCallingFormat()),
        )

    def connection(self):
        if (self.conn is None):
            self.conn = S3Connection(self.accessKey, self.secret, **self.kw)

    def get_key(self, bucket_name, keyname):
        self.connection()
        keyname = ScmPath.normrelativepath(keyname)
        try:
            b = self.conn.get_bucket(bucket_name)
            return b.get_key(keyname)
        except S3ResponseError as e:
            if e.status == 404:
                return None
            raise
        except (BotoClientError, BotoServerError):
            raise

    def stat(self, bucket_name, keyname):
        self.connection()
        k = self.get_key(bucket_name, keyname)
        dic = { 'scality_read': "true" if k is not None else "false" }
        if k is None:
            return dic
        dic['file_update_date'] = k.last_modified
        try:
            dt = datetime.strptime(k.last_modified, '%a, %d %b %Y %H:%M:%S %Z')
            dic['file_update_date_facet'] = dt.strftime('%Y%m')
        except:
            pass
        return dic

    def download_keyname(self, bucket_name, keyname):
        self.connection()
        keyname = ScmPath.normrelativepath(keyname)
        try:
            b = self.conn.get_bucket(bucket_name)
            k = b.get_key(keyname)
            if k is None:
                raise FileNotFoundError
            with self.bd.open_to_download(bucket_name + '/' + keyname) as fp:
                k.get_contents_to_file(fp)
        except (BotoClientError, BotoServerError):
            raise
        return k

    def delete_key(self, key):
        self.connection()
        try:
            if key is None or not key.exists():
                raise FileNotFoundError
            key.delete()
        except (BotoClientError, BotoServerError):
            raise

    def delete_keyname(self, bucket_name, keyname):
        self.connection()
        keyname = ScmPath.normrelativepath(keyname)
        try:
            b = self.conn.get_bucket(bucket_name)
            k = b.get_key(keyname)
            if k is None or not k.exists():
                raise FileNotFoundError
            k.delete()
        except (BotoClientError, BotoServerError):
            raise

    def upload_filename(self, bucket_name, keyname):
        self.connection()
        keyname = ScmPath.normrelativepath(keyname)
        try:
            b = self.conn.get_bucket(bucket_name)
            k = Key(b)
            k.key = keyname
            with self.bd.openr(bucket_name + '/' + keyname) as fp:
                k.set_contents_from_file(fp)
        except (OSError):
            raise
        except (BotoClientError, BotoServerError):
            raise
        return k
