from flask import Flask, request, jsonify
import configparser
import os.path
import sys
import traceback
from myscmlib.s3access import S3Access
from myscmlib.scmpath import ScmPath
from myscmlib.bd import BD

CONFIG_FILENAME = 'scm.ini'
DEFAULT_RESTHOST = '127.0.0.1'
DEFAULT_RESTPORT = 8002
DEFAULT_APPNAME = 'ScalityArchiverRest'

DEFAULT_S3HOST = '127.0.0.1'

DEFAULT_CACHE_DIR = os.path.join(os.path.dirname(__file__), 'cache')
DEFAULT_BD_DEVICE = '/dev/sr0'
DEFAULT_BD_FORMAT = 'ISO'

inifile = configparser.ConfigParser()
inifile.read(os.path.join(os.path.dirname(__file__), CONFIG_FILENAME), 'UTF-8')
try:
    restpart = inifile['rest']
    host = restpart.get('host', DEFAULT_RESTHOST)
    port = restpart.getint('port', DEFAULT_RESTPORT)
    appname = restpart.get('appname', DEFAULT_APPNAME)
except KeyError:
    host = DEFAULT_HOST
    port = DEFAULT_PORT
    appname = DEFAULT_APPNAME

try:
    s3part = inifile['s3']
    s3host = s3part.get('host', DEFAULT_S3HOST)
    s3accessKey = s3part.get('accessKey')
    s3secret = s3part.get('secret')
except KeyError:
    raise

if (s3accessKey is None or s3secret is None):
    sys.exit("You need accessKey and secret in " + CONFIG_FILENAME)

try:
    bdpart = inifile['bd']
    bdcache_dir = bdpart.get('cache_dir', DEFAULT_CACHE_DIR)
    bddevice = bdpart.get('device', DEFAULT_BD_DEVICE)
    bdformat = bdpart.get('format', DEFAULT_BD_FORMAT)
except KeyError:
    bdcache_dir = DEFAULT_CACHE_DIR
    bddevice = DEFAULT_BD_DEVICE
    bdformat = DEFAULT_BD_FORMAT

bd = BD(bdcache_dir, device=bddevice, format=bdformat)
access = S3Access(s3accessKey, s3secret, s3host, bd=bd)

app = Flask(__name__)

def make_layer_response(result, error="", magazine_list=[]):
    if result == 0:
        return {
            "result": result
        }
    elif result == 10:
        return {
            "result": result,
            "magazine_list": magazine_list
        }
    else:
        return {
            "result": result,
            "data": {
                "err_msg_detail": error
            }
        }

def archive(bucket, path):
    try:
        k = access.download_keyname(bucket, path)
        access.delete_key(k)
        return jsonify(make_layer_response(0, "Archived!"))
    except FileNotFoundError as e:
        return jsonify(make_layer_response(103, path + ': not found on S3'))
    except BotoClientError as e:
        return jsonify(make_layer_response(999, path + ': failed to read from S3'))

def backup(bucket, path):
    try:
        access.download_keyname(bucket, path)
        return jsonify(make_layer_response(0, "Backuped!"))
    except FileNotFoundError as e:
        return jsonify(make_layer_response(103, path + ': not found on S3'))
    except BotoClientError as e:
        return jsonify(make_layer_response(999, path + ': failed to read from S3'))

def retrieve(bucket, path):
    '''
    In the case that specified file(key) name is already existing on S3 server,
    it will fail although the behaviour is not described on the specified
    '''
    if access.get_key(bucket, path) is not None:
        return jsonify(make_layer_response(112, bucket + '/' + path + ': already existing on ' + s3host))
    try:
        access.upload_filename(bucket, path)
        return jsonify(make_layer_response(0, "Retrieved"))
    except FileNotFoundError as e:
        return jsonify(make_layer_response(307, path + ': not found on BD'))
    except BotoClientError as e:
        return jsonify(make_layer_response(112, path + ': failed to write to S3'))

@app.route("/" + appname + "/layer", methods=['PUT'])
def layer():
    bucket = request.args.get('bucket')
    path = request.args.get('path')
    mode = request.args.get('mode')
    if ((bucket is None) or (path is None) or (mode is None)):
        return jsonify(make_layer_response(100, "Incomplete parameters"))
    print(bucket + '/' + path + ' at ' + mode)
    if (mode == 'archive'):
        return archive(bucket, path)
    elif (mode == 'backup'):
        return backup(bucket, path)
    elif (mode == 'retrieve'):
        return retrieve(bucket, path)
    else:
        return jsonify(make_layer_response(100, "Invalid mode: " + mode))

def make_details(result, error="", doc={}):
    if result == 0:
        return {
            "result": result,
            "details_response": {
                "doc": [
                    doc
                ]
            }
        }
    else:
        return {
            "result": result,
            "data": {
                "err_msg_detail": error
            }
        }

def extract_message(e):
    traceback.print_exc()
    if hasattr(e, 'status') and hasattr(e, 'reason'):
        return 'S3: ' + str(e.status) + ': ' + e.reason
    elif hasattr(e, 'message'):
        return e.message
    elif hasattr(e, 'strerror'):
        return e.strerror
    elif hasattr(e, 'output'):
        return e.output
    else:
        return str(e)

@app.route("/" + appname + "/get_details")
def get_details():
    full = request.args.get('path')
    if full is None:
        return jsonify(make_details(100, error="Incomplete parameters"))
    comps = ScmPath.normrelativepath(full).split(os.sep)
    if len(comps) < 3:
        return jsonify(make_details(100, error="Incomplete parameters"))
    tenant = comps.pop(0)
    bucket = comps.pop(0)
    path = '/'.join(comps)
    dic1 = {
            "container_name": bucket,
            "file_name": os.path.basename(path),
            "local_file_path": full,
            "file_type": os.path.splitext(path)[1]
    }
    try:
        dic2 = access.stat(bucket, path)
        dic2['relocation'] = "true" if bd.existp(bucket + '/' + path) else ""
        return jsonify(make_details(0, doc={**dic1, **dic2}))
    except Exception as e:
        traceback.print_exc()
        return jsonify(make_details(999,
            error=extract_message(e)))

@app.route("/" + appname + "/bdflush", methods=['PUT'])
def flush():
    clean = request.args.get('clean', False)
    try:
        count = bd.bdflush(clean)
        return(jsonify({
            "result": 0,
            "files": count
            }
        ))
    except (OSError, RuntimeError) as e:
        error=extract_message(e)
        return(jsonify({
            "result": 100,
            "data": {
                "err_msg_detail": error
            }
            }
        ))

@app.route("/" + appname + "/bdinit", methods=['PUT'])
def bdinit():
    try:
        str = bd.bdinit()
        return(jsonify({
            "result": 0,
            "uuid": str
            }
        ))
    except (OSError, RuntimeError) as e:
        error=extract_message(e)
        return(jsonify({
            "result": 100,
            "data": {
                "err_msg_detail": error
            }
            }
        ))

if __name__ == "__main__":
    app.run(host=host, port=port)
