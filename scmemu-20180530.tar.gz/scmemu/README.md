# HotCold用SCMエミュレータおよびS3ストレージの使い方
##

HotCold用SCMエミュレータは
- Hotストレージ(S3ストレージ)
- Coldストレージ兼SCMエミュレータ
の2台構成を想定しています。それぞれ後述の通りインストール・実行してください。

## S3ストレージの準備

Scality製S3ストレージをインストールし、Hotストレージとして使用します。

### インストール

Ubuntu 18.04では以下の手順でS3ストレージをインストールしてください。詳しくは[https://github.com/scality/S3]を参照してください。
1. apt-get install nodejs (要sudo)
2. apt-get install npm (要sudo)
3. git clone https://github.com/scality/S3.git
4. cd S3
5. npm install

### 設定

動作設定(config.json)およびユーザーアクセス設定(res/authdata.json)を変更してください。

#### config.json

S3のトップディレクトリにあるconfig.json内のrestEndpointsにインストールするホストのホスト名を設定してください。
このホスト名はSCMエミュレータがS3ストレージにアクセスする場合のホスト名です。
たとえばホスト名hcs3およびFQDN hcs3.example.comでアクセスする場合は以下のような差分になります。

```
--- a/config.json
+++ b/config.json
@@ -3,6 +3,8 @@
     "listenOn": [],
     "replicationGroupId": "RG001",
     "restEndpoints": {
+       "hcs3": "us-east-1",
+       "hcs3.example.com": "us-east-1",
         "localhost": "us-east-1",
         "127.0.0.1": "us-east-1",
         "cloudserver-front": "us-east-1",
```

ここで設定した名前以外でアクセスするとエラーになりますので必要なだけ設定してください。
ポート番号("port")は適宜変更してください。

#### conf/authdata.json

conf/authdata.jsonにはアクセス制御用の情報を記述します。accounts配列に既存アカウントが記載されているので適宜編集してください。
アクセス時には各アカウントの"keys"配列にある"access"(アクセスキー)および"secret"(シークレットキー)を用います。
クライアントおよびSCMエミュレータからのアクセスに必要になります。

### 起動

起動はS3のトップディレクトリから以下のようにしてください。(Bashの場合)

```
REMOTE_MANAGEMENT_DISABLE=1 S3DATAPATH=/mnt/store/localData S3METADATAPATH=/mnt/store/localMetadata npm start
```
S3DATAPATHおよびS3METADATAPATHはファイルを置かれるディレクトリです。環境にあわせて変更してください。それぞれ予め書き込みのできるディレクトリを作っておく必要があります。停止はCtrl-Cです。

## Preparing for scmemu

SCMエミュレータは以下のように準備します。

### Install virtualenv if needed

Ubuntu 18.04では以下のようにapt-getを用いてvirtualをインストールしてください。

```
apt-get install python3-venv
```
### or

特定のパッケージ管理システムがないOSの場合はpipを用いてvirtualenvをインストールしてください。

```
pip install virtualenv
```

### Setup virtualenv

scmemuのトップディレクトリ(このREADMEが存在するディレクトリ)をvirtualenv環境として設定してください。
this_directoryは実際のディレクトリで置き換えてください。

```
python -m venv this_directory
. this_directory/bin/activate
pip install wheel
pip install flask
```

python -m venvおよびpip install はそれぞれ最初の設定時におこなってください。activateの実行は新規のshellごとに実行が必要です。

### 設定

設定ファイルはscm.iniです。各設定値については後述します。scm.ini.sampleを参照したうえでファイルを作成してください。

### 起動

起動はactivate実行済み環境のscmemuのトップディレクトリから以下のようにしてください。

```
python scmemu.py
```

curl等httpクライアントでAPIにアクセスしてください。実装済みAPIは後述します。rootではなくBDデバイスにアクセスできる一般ユーザーでの実行を想定しています。

## scm.ini

scm.iniには以下の各セクションが存在します。それぞれ解説します。
- rest
- s3
- bd

### rest

restセクションにはscmemu自体のRESTサーバー機能についての設定を記述します。設定項目は以下の通りです。

- host
  bindする(待受する)ホスト名もしくはIPアドレスです。初期値は0.0.0.0です。
- port
  bindする(待ち受けする)ポート番号です。初期値は8002です。
- appname
  RESTのURL中に含まれるアプリケーション名です。初期値はScalityArchiverRestです。

### s3

s3セクションにはS3ストレージにアクセスするための設定を記述します。設定項目は以下通りです。

- host
  S3ストレージのホスト名を記述します。S3ストレージの設定config.jsonに含まれる名前にしてください。初期値は127.0.0.1です。
- accessKey
  S3ストレージアクセスするためのアクセスキーを記述します。S3ストレージの設定authdata.jsonに含まれるているキーを記入してください。
- secret
  S3ストレージアクセスするためのシークレットキーを記述します。S3ストレージの設定authdata.jsonに含まれるているキーを記入してください。

### bd

bdセクションにはBDおよびキャッシュディレクトリの設定を記述します。設定項目は以下の通りです。

- cache_dir
  キャッシュのディレクトリ名を設定します。予め作っておく必要はありませんがscmエミュレータを実行するユーザーから書き込みができる必要があります。初期値は"."です。
- device
  BDのデバイスファイル名を設定します。scmエミュレータを実行するユーザーから書き込みができる必要があります。初期値は/dev/sr0です。Ubuntu 18.04においてはインストーラから作ったユーザーは/dev/sr0に書き込み可能なcdromグループにはいっています。
- format
  BDデバイスのフォーマットを設定します。初期値はISOです。開発用です、通常は設定しないでください。

## API

以下のSCM APIが実装済みです。アクセス制限はありませんのでご注意ください。

- layer
- get_details

また以下の独自APIが追加されています。

- bdinit
- bdflush

リターン値はjson形式でリターンコードはresultに含まれています。

### layer

ファイルのarchive,backup,retriveを実行します。実装済みのリターンコードは以下の通りです。

Return code |  意味
-----------:|:----
0           | 正常実行
100         | パラメータ不足または誤りがある
103         | ファイルが存在しない
112         | S3ストレージへに書き込みに失敗した
307         | BDおよびキャッシュディレクトリにファイルが存在しない
999         | その他のエラー

使用例
```
curl -XPUT 'http://hcbd:8080/ScalityArchiverRest/layer?mode=archive&bucket=test1&path=file1'
```
#### 注意点
- 処理完了を待って結果を返すので大きなファイルでは時間がかかるかもしれません

### get_details

ファイルの詳細情報を取得します。実装済みのリターンコードは以下の通りです。

Return code |  意味
-----------:|:----
0           | 正常実行
100         | パラメータ不足または誤りがある
999         | その他のエラー

使用例
```
curl -XGET 'http://hcbd:8080/ScalityArchiverRest/get_details?path=/tenant1/test1/file1'
```

#### 注意点
- tenant情報は使用していません

### bdinit

BDメディアを初期化します。新規のメディアを使用する際に一度だけ呼び出してください。

Return code |  意味
-----------:|:----
0           | 正常実行(メディアに設定したuuid文字列を返します)
100         | 初期化に失敗した(エラーメッセージをdata.err_msg_detailに入れて返します)

使用例
```
curl -XPUT 'http://hcbd:8080/ScalityArchiverRest/bdinit'
```
エラーの例
```
{"data":{"err_msg_detail":":-[ LOAD TRAY failed with SK=5h/INVALID FIELD IN CDB]: Input/output error\n"},"result":100}
```

#### 注意点
- 成功するとBDの内容が消去されますが、BD-R等書き直しのできないメディアでは容量は回復しません

### bdflush

S3からlayerコマンド(mode=archive or backup)でSCMのローカルHDDにダウンロードされたファイルを初期化済みBDメディアに書き込みます。
cron等で定期的に呼んでください。オプションによりHDD中のキャッシュを消去するかどうかを変更できます。

Return code |  意味
-----------:|:----
0           | 正常実行(メディアに書き込んだfilesファイル数を返します)
100         | 書き込みに失敗した(エラーメッセージをdata.err_msg_detailに入れて返します)

使用例(cleanオプションありでキャッシュを消去)
```
curl -XPUT 'http://hcbd:8080/ScalityArchiverRest/bdflush'
curl -XPUT 'http://hcbd:8080/ScalityArchiverRest/bdflush?clean=true'
```
エラーの例
```
{"data":{"err_msg_detail":"failed to write files to bd"},"result":100}
```

## Known Issues

- BDメディアの自動入れ替えには対応しません。対応予定もありません
- 同時に管理できるBDメディアは1枚のみです。他のメディアにファイルがあるかどうかも管理していませんので、現状ではretrieve前に予めメディアを入れ替えておく必要があります
- HDD容量の管理をしていません。cleanなしでbdflushを使い続けるとあふれるかもしれません。
- APIレスポンスはJSON形式ですが、富士通様のマニュアルにあるのとは異なりリターン値の名前(オブジェクト名)を""でくくっています。これはJSONの仕様です。
  例:
  ```
  result <-> "result"
  ```
- SCM APIに対するアクセス制限はありません
